﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CodeChallenge.Entities
{
    public class ZipcodeGroup
    {
        [Required(ErrorMessage = "Start zipcode is required.")]
        public string Start { get; set; }

        [Required(ErrorMessage = "End zipcode is required.")]
        public string End { get; set; }
    }
}