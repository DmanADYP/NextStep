﻿using CodeChallenge.Data.Repositories;
using CodeChallenge.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CodeChallenge.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "RegionsService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select RegionsService.svc or RegionsService.svc.cs at the Solution Explorer and start debugging.
    public class RegionsService : IRegionsService
    {
        public void DoWork()
        {
        }

        public void AddRegions(string name, List<string> zipcodes)
        {
            if (!string.IsNullOrEmpty(name) && zipcodes != null && zipcodes.Count() == 2)
            {
                List<ZipcodeGroup> oList = new List<ZipcodeGroup>() { new ZipcodeGroup() { Start = zipcodes[0], End = zipcodes[1] } };
                Region oRegion = new Region() { Id = Guid.NewGuid(), Name = name, Zipcodes = oList };
                RegionRepository oRegionRepository = new RegionRepository();

                oRegionRepository.Add(oRegion);
            }
        }
    }
}
