﻿using CodeChallenge.Api.Controllers;
using CodeChallenge.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CodeChallenge.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddRegion()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult AddRegion(string name, List<string> zipcodes)
        {
            RegionsController oRegionsController = new RegionsController();
            oRegionsController.AddRegion(name, zipcodes);
            return View();
        }

        public ActionResult GetRegion()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult GetRegion(string regoinId)
        {
            Guid regionIdGuid;
            Region model = new Region();

            if (Guid.TryParse(regoinId, out regionIdGuid))
            {
                RegionsController oRegionsController = new RegionsController();
                model = oRegionsController.GetRegion(regionIdGuid);
            }

            return View(model);
        }

        public ActionResult RemoveRegion()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult RemoveRegion(string regoinId)
        {
            Guid regionIdGuid;

            if (Guid.TryParse(regoinId, out regionIdGuid))
            {
                RegionsController oRegionsController = new RegionsController();
                oRegionsController.GetRegion(regionIdGuid);
            }

            return View();
        }
    }
}