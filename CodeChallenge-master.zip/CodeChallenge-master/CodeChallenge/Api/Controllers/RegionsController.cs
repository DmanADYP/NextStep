﻿using CodeChallenge.Data.Repositories;
using CodeChallenge.Entities;
using CodeChallenge.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace CodeChallenge.Api.Controllers
{
    public class RegionsController : ApiController
    {
        public void AddRegion(string name, List<string> zipcodes)
        {
            using (RegionsServiceReference.RegionsServiceClient oRegionsService = new RegionsServiceReference.RegionsServiceClient())
            {
                oRegionsService.AddRegions(name, zipcodes.ToArray());
            }
        }

        public Region GetRegion(Guid regionIdGuid)
        {
            RegionRepository oRegionRepository = new RegionRepository();
            return oRegionRepository.Get(regionIdGuid);
        }

        public void RemoveRegion(Guid regionIdGuid)
        {
            RegionRepository oRegionRepository = new RegionRepository();
            oRegionRepository.Remove(regionIdGuid);
        }
    }
}